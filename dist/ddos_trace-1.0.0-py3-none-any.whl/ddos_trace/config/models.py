"""配置模块 - 提供所有配置数据类及配置文件加载"""

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

import yaml


@dataclass
class ClickHouseConfig:
    """ClickHouse 连接配置"""

    host: str = "localhost"
    port: int = 9000
    username: str = "default"
    password: str = ""
    database: str = "uniflow_controller_clickhouse_trunk"
    table_name: str = "analytics_netflow_dist"
    alert_table_name: str = "detect_attack_dist"
    timeout: int = 30
    chunk_size: int = 100000

    @property
    def connection_params(self) -> dict:
        return {
            "host": self.host,
            "port": self.port,
            "username": self.username,
            "password": self.password,
            "database": self.database,
            "connect_timeout": self.timeout,
            "send_receive_timeout": self.timeout,
        }


@dataclass
class ThresholdConfig:
    """阈值配置"""

    pps_threshold: int = 500_000
    bps_threshold: int = 20_000_000


@dataclass
class TracebackConfig:
    """溯源配置"""

    min_cluster_size: int = 5
    use_dynamic_baseline: bool = True
    target_ips: List[str] = field(default_factory=list)
    target_mo_codes: List[str] = field(default_factory=list)

    confirmed_threshold: float = 80.0
    suspicious_threshold: float = 60.0
    borderline_threshold: float = 40.0

    cluster_features: List[str] = field(default_factory=lambda: [
        "bytes_per_packet",
        "packets_per_sec",
        "bytes_per_sec",
        "burst_ratio",
        "burst_count",
        "flow_interval_mean",
        "flow_interval_cv",
        "dst_port_count",
        "protocol_count",
    ])

    PROTO_ICMP: int = 1
    PROTO_TCP: int = 6
    PROTO_UDP: int = 17
    max_samples_for_clustering: int = 10_000


@dataclass
class ApiConfig:
    """API 服务配置"""

    host: str = "0.0.0.0"
    port: int = 8000


@dataclass
class OutputConfig:
    """输出配置"""

    dir: str = "./output"


@dataclass
class AppConfig:
    """应用总配置"""

    clickhouse: ClickHouseConfig = field(default_factory=ClickHouseConfig)
    threshold: ThresholdConfig = field(default_factory=ThresholdConfig)
    traceback: TracebackConfig = field(default_factory=TracebackConfig)
    api: ApiConfig = field(default_factory=ApiConfig)
    output: OutputConfig = field(default_factory=OutputConfig)


def load_config(config_path: Optional[str] = None) -> AppConfig:
    """
    从 YAML 文件加载配置，支持环境变量覆盖

    优先级：环境变量 > config.yaml > 默认值

    Args:
        config_path: 配置文件路径，默认为项目根目录的 config.yaml

    Returns:
        AppConfig 实例
    """
    if config_path is None:
        # 按优先级查找配置文件
        candidates = [
            Path("config.yaml"),
            Path("config.yml"),
            Path(__file__).resolve().parents[3] / "config.yaml",
        ]
        for p in candidates:
            if p.exists():
                config_path = str(p)
                break

    raw: dict = {}
    if config_path and Path(config_path).exists():
        with open(config_path, "r", encoding="utf-8") as f:
            raw = yaml.safe_load(f) or {}

    ch = raw.get("clickhouse", {})
    # 环境变量覆盖 ClickHouse 配置
    clickhouse_config = ClickHouseConfig(
        host=os.getenv("DDOS_CH_HOST", ch.get("host", "localhost")),
        port=int(os.getenv("DDOS_CH_PORT", ch.get("port", 9000))),
        username=os.getenv("DDOS_CH_USER", ch.get("username", "default")),
        password=os.getenv("DDOS_CH_PASSWORD", ch.get("password", "")),
        database=os.getenv("DDOS_CH_DATABASE", ch.get("database", "uniflow_controller_clickhouse_trunk")),
        table_name=os.getenv("DDOS_CH_TABLE", ch.get("table_name", "analytics_netflow_dist")),
        alert_table_name=os.getenv("DDOS_CH_ALERT_TABLE", ch.get("alert_table_name", "detect_attack_dist")),
        timeout=int(os.getenv("DDOS_CH_TIMEOUT", ch.get("timeout", 30))),
        chunk_size=int(os.getenv("DDOS_CH_CHUNK", ch.get("chunk_size", 100000))),
    )

    th = raw.get("threshold", {})
    threshold_config = ThresholdConfig(
        pps_threshold=int(th.get("pps_threshold", 500_000)),
        bps_threshold=int(th.get("bps_threshold", 20_000_000)),
    )

    tb = raw.get("traceback", {})
    traceback_config = TracebackConfig(
        min_cluster_size=int(tb.get("min_cluster_size", 5)),
        use_dynamic_baseline=bool(tb.get("use_dynamic_baseline", True)),
        max_samples_for_clustering=int(tb.get("max_samples_for_clustering", 10_000)),
    )

    ap = raw.get("api", {})
    api_config = ApiConfig(
        host=os.getenv("DDOS_API_HOST", ap.get("host", "0.0.0.0")),
        port=int(os.getenv("DDOS_API_PORT", ap.get("port", 8000))),
    )

    ou = raw.get("output", {})
    output_config = OutputConfig(
        dir=ou.get("dir", "./output"),
    )

    return AppConfig(
        clickhouse=clickhouse_config,
        threshold=threshold_config,
        traceback=traceback_config,
        api=api_config,
        output=output_config,
    )
