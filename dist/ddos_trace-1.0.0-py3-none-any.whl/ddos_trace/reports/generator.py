"""报告生成与导出模块"""

import logging
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


class ReportGenerator:
    """生成分析报告、CSV 导出、可视化图表"""

    def __init__(self, output_dir: str = "."):
        self.output_dir = output_dir

    def generate_text_report(
        self,
        features: pd.DataFrame,
        cluster_report: Optional[pd.DataFrame],
        path_analysis: Dict,
        effective_thresholds: Dict,
    ) -> str:
        """
        生成文字分析报告

        Args:
            features: 带分类的特征 DataFrame
            cluster_report: 聚类报告（可能为 None）
            path_analysis: 路径分析结果
            effective_thresholds: 有效阈值

        Returns:
            报告文本
        """
        lines = []

        # 1. 分析摘要
        lines.append("=" * 60)
        lines.append("DDoS 攻击溯源分析报告")
        lines.append("=" * 60)

        # 时间显示：parser_rcv_time 聚合后仍是毫秒值，需转换
        start_val = features['flow_start_time'].min()
        end_val = features['flow_end_time'].max()
        try:
            start_str = pd.to_datetime(start_val, unit='ms').strftime('%Y-%m-%d %H:%M:%S')
            end_str = pd.to_datetime(end_val, unit='ms').strftime('%Y-%m-%d %H:%M:%S')
        except (ValueError, TypeError):
            start_str = str(start_val)
            end_str = str(end_val)
        lines.append(f"\n分析时间窗口: {start_str} ~ {end_str}")
        lines.append(f"源 IP 总量: {len(features)}")
        lines.append(f"有效阈值: PPS={effective_thresholds.get('packets_per_sec', 'N/A'):.0f}, "
                     f"BPS={effective_thresholds.get('bytes_per_sec', 'N/A'):.0f}")

        # 2. 流量分类摘要
        lines.append(f"\n{'─' * 40}")
        lines.append("流量分类摘要")
        lines.append(f"{'─' * 40}")

        for cls in ["confirmed", "suspicious", "borderline", "background"]:
            mask = features["traffic_class"] == cls
            count = mask.sum()
            cls_features = features[mask]
            if count > 0:
                avg_conf = cls_features["attack_confidence"].mean()
                total_pkt = cls_features["total_packets"].sum()
                lines.append(f"  {cls:12s}: IP数={count:6d}, 总包数={total_pkt:12.0f}, 平均置信度={avg_conf:.1f}")

        # 3. Top-10 确认攻击源
        confirmed = features[features["traffic_class"] == "confirmed"].sort_values(
            "attack_confidence", ascending=False
        )
        if not confirmed.empty:
            lines.append(f"\n{'─' * 40}")
            lines.append("Top-10 确认攻击源")
            lines.append(f"{'─' * 40}")
            top10 = confirmed.head(10)
            for ip, row in top10.iterrows():
                lines.append(
                    f"  {str(ip):18s} | 置信度={row['attack_confidence']:.1f} | "
                    f"PPS={row.get('packets_per_sec', 0):.0f} | "
                    f"BPS={row.get('bytes_per_sec', 0):.0f} | "
                    f"原因: {row.get('confidence_reasons', '')}"
                )

        # 4. 背景流量特征均值
        background = features[features["traffic_class"] == "background"]
        if not background.empty:
            lines.append(f"\n{'─' * 40}")
            lines.append("背景流量特征均值")
            lines.append(f"{'─' * 40}")
            for col in ["packets_per_sec", "bytes_per_sec", "bytes_per_packet",
                        "burst_ratio", "flow_interval_cv"]:
                if col in background.columns:
                    lines.append(f"  {col:25s}: {background[col].mean():.2f}")

        # 5. 指纹聚类摘要
        if cluster_report is not None and not cluster_report.empty:
            lines.append(f"\n{'─' * 40}")
            lines.append("指纹聚类摘要")
            lines.append(f"{'─' * 40}")
            lines.append(f"  集群数: {cluster_report['cluster_id'].nunique()}")
            for _, row in cluster_report.iterrows():
                lines.append(
                    f"  集群{row['cluster_id']}: 成员数={row['member_count']}, "
                    f"攻击类型={row.get('attack_type', '未知')}"
                )

        lines.append("\n" + "=" * 60)
        report_text = "\n".join(lines)
        logger.info("[REPORT] 文字报告生成完成 / 行数[%d]", len(lines))
        return report_text

    def export_traffic_classification_csv(
        self, features: pd.DataFrame, filename: str = "traffic_classification_report.csv"
    ) -> str:
        """导出流量分类报告 CSV"""
        filepath = f"{self.output_dir}/{filename}"
        export_cols = [
            "attack_confidence", "traffic_class", "confidence_reasons",
            "total_packets", "total_bytes", "packets_per_sec", "bytes_per_sec",
            "bytes_per_packet", "burst_ratio", "flow_duration",
            "dst_port_count", "protocol_count", "flow_count",
            "country", "province", "city", "isp",
        ]
        available = [c for c in export_cols if c in features.columns]
        features[available].to_csv(filepath, encoding="utf-8-sig")
        logger.info("[REPORT] CSV导出: %s", filepath)
        return filepath

    def export_cluster_report_csv(
        self, cluster_report: Optional[pd.DataFrame],
        filename: str = "cluster_fingerprint_report.csv",
    ) -> Optional[str]:
        """导出聚类报告 CSV"""
        if cluster_report is None or cluster_report.empty:
            return None
        filepath = f"{self.output_dir}/{filename}"
        cluster_report.to_csv(filepath, index=False, encoding="utf-8-sig")
        logger.info("[REPORT] CSV导出: %s", filepath)
        return filepath

    def plot_cluster_radar_chart(
        self,
        cluster_report: Optional[pd.DataFrame],
        filename: str = "cluster_radar_chart.png",
    ) -> Optional[str]:
        """绘制集群指纹雷达图"""
        if cluster_report is None or cluster_report.empty:
            return None

        try:
            import matplotlib
            matplotlib.use("Agg")
            import matplotlib.pyplot as plt
        except ImportError:
            logger.warning("[REPORT] matplotlib 未安装，跳过雷达图")
            return None

        # 提取特征列
        avg_cols = [c for c in cluster_report.columns if c.startswith("avg_")]
        if not avg_cols:
            return None

        labels = [c.replace("avg_", "") for c in avg_cols]
        n_clusters = len(cluster_report)

        # 对数归一化
        data = cluster_report[avg_cols].values.copy()
        data = np.log1p(np.abs(data))
        # Min-Max 归一化
        col_min = data.min(axis=0)
        col_max = data.max(axis=0)
        col_range = col_max - col_min
        col_range[col_range == 0] = 1
        data_norm = (data - col_min) / col_range

        # 绘制极坐标雷达图
        angles = np.linspace(0, 2 * np.pi, len(labels), endpoint=False).tolist()
        angles += angles[:1]

        fig, ax = plt.subplots(figsize=(8, 8), subplot_kw=dict(polar=True))

        colors = plt.cm.tab10(np.linspace(0, 1, max(n_clusters, 1)))
        for i in range(n_clusters):
            values = data_norm[i].tolist()
            values += values[:1]
            ax.plot(angles, values, "o-", linewidth=2, color=colors[i],
                    label=f"Cluster {cluster_report.iloc[i]['cluster_id']}")
            ax.fill(angles, values, alpha=0.15, color=colors[i])

        ax.set_xticks(angles[:-1])
        ax.set_xticklabels(labels, fontsize=9)
        ax.set_title("攻击集群指纹雷达图", fontsize=14, pad=20)
        ax.legend(loc="upper right", bbox_to_anchor=(1.3, 1.0))

        filepath = f"{self.output_dir}/{filename}"
        fig.savefig(filepath, dpi=150, bbox_inches="tight")
        plt.close(fig)
        logger.info("[REPORT] 雷达图保存: %s", filepath)
        return filepath
