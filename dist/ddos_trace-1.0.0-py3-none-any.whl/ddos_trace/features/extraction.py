"""特征提取模块 - 基础聚合特征、衍生特征、时序特征"""

import logging
from typing import Dict, List

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


class FeatureExtractor:
    """按 src_ip_addr 聚合提取多维特征"""

    def extract(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        执行完整的特征提取流程

        Args:
            df: 预处理后的 NetFlow DataFrame

        Returns:
            以 src_ip_addr 为索引的特征 DataFrame
        """
        if df.empty:
            return pd.DataFrame()

        logger.info("[FEATURES] 开始特征提取 / 原始记录数[%d]", len(df))

        # 预计算列
        df = self._precompute(df)

        # 基础聚合特征
        features = self._aggregate_basic(df)

        # 衍生特征
        features = self._compute_derived(features)

        # 时序特征
        temporal = self._extract_temporal_features(df)
        features = features.join(temporal, how="left")

        # 地理/监测对象众数
        features = self._aggregate_categorical(df, features)

        logger.info(
            "[FEATURES] 特征提取完成 / 唯一源IP[%d] / 特征维度[%d]",
            len(features),
            len(features.columns),
        )
        return features

    # ------------------------------------------------------------------
    # 预计算
    # ------------------------------------------------------------------

    def _precompute(self, df: pd.DataFrame) -> pd.DataFrame:
        """在原始 DataFrame 上预计算辅助列"""
        df = df.copy()

        # 端口集中度：Herfindahl 指数 (per src_ip，后面聚合时用)
        # 这里先不做，留给聚合阶段

        return df

    # ------------------------------------------------------------------
    # 基础聚合
    # ------------------------------------------------------------------

    def _aggregate_basic(self, df: pd.DataFrame) -> pd.DataFrame:
        """按 src_ip_addr 聚合基础统计特征"""
        agg_dict: Dict[str, List] = {
            # 包统计
            "packets": ["sum", "mean", "std", "max", "min"],
            # 字节统计
            "octets": ["sum", "mean", "std", "max"],
            # 多样性
            "dst_port": ["nunique"],
            "src_port": ["nunique"],
            "protocol": ["nunique"],
            "input_if_index": ["nunique"],
            "output_if_index": ["nunique"],
            "flow_ip_addr": ["nunique"],
            # 时间
            "parser_rcv_time": ["min", "max", "count"],
        }

        grouped = df.groupby("src_ip_addr").agg(agg_dict)

        # 扁平化多级列名
        grouped.columns = [
            self._flatten_col(col)
            for col in grouped.columns
        ]

        features = grouped.rename(columns={
            "packets_sum": "total_packets",
            "packets_mean": "avg_packets",
            "packets_std": "std_packets",
            "packets_max": "max_packets",
            "packets_min": "min_packets",
            "octets_sum": "total_bytes",
            "octets_mean": "avg_bytes",
            "octets_std": "std_bytes",
            "octets_max": "max_bytes",
            "dst_port_nunique": "dst_port_count",
            "src_port_nunique": "src_port_count",
            "protocol_nunique": "protocol_count",
            "input_if_index_nunique": "input_if_count",
            "output_if_index_nunique": "output_if_count",
            "flow_ip_addr_nunique": "flow_ip_count",
            "parser_rcv_time_min": "flow_start_time",
            "parser_rcv_time_max": "flow_end_time",
            "parser_rcv_time_count": "flow_count",
        })

        # 流持续时间（秒）
        features["flow_duration"] = (
            (features["flow_end_time"] - features["flow_start_time"]) / 1000.0
        )
        # 最少 1 秒，避免除零
        features["flow_duration"] = features["flow_duration"].clip(lower=1.0)

        return features

    @staticmethod
    def _flatten_col(col: tuple) -> str:
        """将 ('packets', 'sum') → 'packets_sum'"""
        if isinstance(col, tuple):
            return "_".join(str(c) for c in col if c)
        return str(col)

    # ------------------------------------------------------------------
    # 衍生特征
    # ------------------------------------------------------------------

    def _compute_derived(self, features: pd.DataFrame) -> pd.DataFrame:
        """计算衍生指标"""
        features = features.copy()

        # 平均包大小
        features["bytes_per_packet"] = (
            features["total_bytes"] / features["total_packets"]
        ).replace([np.inf, -np.inf], 0)

        # 每秒包数 / 字节数
        features["packets_per_sec"] = (
            features["total_packets"] / features["flow_duration"]
        ).replace([np.inf, -np.inf], 0)

        features["bytes_per_sec"] = (
            features["total_bytes"] / features["flow_duration"]
        ).replace([np.inf, -np.inf], 0)

        # 突发比例
        features["burst_ratio"] = (
            features["max_packets"] / features["avg_packets"]
        ).replace([np.inf, -np.inf], 0)

        # 字节变异性
        features["bytes_std_ratio"] = (
            features["std_bytes"] / features["avg_bytes"]
        ).replace([np.inf, -np.inf], 0)

        return features

    # ------------------------------------------------------------------
    # 时序特征（全向量化，无逐 IP 循环）
    # ------------------------------------------------------------------

    def _extract_temporal_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        全向量化提取时序特征

        基于 parser_rcv_time 计算：
        - flow_interval_mean / std / cv
        - burst_count / max_burst_size
        - active_ratio
        """
        if "parser_rcv_time" not in df.columns:
            return pd.DataFrame(index=df["src_ip_addr"].unique())

        # 按源IP + 时间排序
        sorted_df = df[["src_ip_addr", "parser_rcv_time"]].sort_values(
            ["src_ip_addr", "parser_rcv_time"]
        )

        # 计算相邻流时间间隔（毫秒）
        sorted_df["time_diff"] = sorted_df.groupby("src_ip_addr")["parser_rcv_time"].diff()

        # 间隔统计（毫秒 → 秒）
        interval_stats = sorted_df.groupby("src_ip_addr")["time_diff"].agg(
            flow_interval_mean="mean",
            flow_interval_std="std",
        )
        # 转为秒
        interval_stats["flow_interval_mean"] = interval_stats["flow_interval_mean"] / 1000.0
        interval_stats["flow_interval_std"] = interval_stats["flow_interval_std"] / 1000.0

        # 变异系数 CV
        interval_stats["flow_interval_cv"] = np.where(
            interval_stats["flow_interval_mean"] > 0,
            interval_stats["flow_interval_std"] / interval_stats["flow_interval_mean"],
            0.0,
        )
        interval_stats["flow_interval_cv"] = interval_stats["flow_interval_cv"].fillna(0.0)

        # 突发检测：间隔 < 1s（1000ms）
        sorted_df["is_burst"] = (sorted_df["time_diff"] < 1000) & (sorted_df["time_diff"].notna())

        # burst_count：间隔 < 1s 的次数
        burst_stats = sorted_df.groupby("src_ip_addr")["is_burst"].agg(
            burst_count="sum",
        )
        burst_stats["burst_count"] = burst_stats["burst_count"].astype(int)

        # max_burst_size：连续突发的最大长度（游程编码）
        max_burst = (
            sorted_df.groupby("src_ip_addr")["is_burst"]
            .apply(self._max_run_length)
            .rename("max_burst_size")
        )

        # 活跃时间占比
        duration_ms = sorted_df.groupby("src_ip_addr")["parser_rcv_time"].agg(
            first_val="min",
            last_val="max",
            count_val="count",
        )
        active_stats = pd.DataFrame(index=duration_ms.index)
        total_span_ms = duration_ms["last_val"] - duration_ms["first_val"]
        active_stats["active_ratio"] = np.where(
            total_span_ms > 0,
            (duration_ms["count_val"] - 1) / (total_span_ms / 1000.0),
            1.0,
        ).clip(upper=1.0)

        # 合并所有时序特征
        temporal = interval_stats.join(burst_stats, how="left").join(
            max_burst, how="left"
        ).join(active_stats, how="left")

        # 填充缺失值
        temporal = temporal.fillna({
            "burst_count": 0,
            "max_burst_size": 0,
        })

        logger.info(
            "[FEATURES] 时序特征提取完成 / 唯一源IP[%d]",
            len(temporal),
        )
        return temporal

    @staticmethod
    def _max_run_length(series: pd.Series) -> int:
        """计算布尔序列中 True 的最大连续长度"""
        if series.empty or not series.any():
            return 0
        max_len = 0
        current = 0
        for val in series:
            if val:
                current += 1
                max_len = max(max_len, current)
            else:
                current = 0
        return max_len

    # ------------------------------------------------------------------
    # 分类特征众数
    # ------------------------------------------------------------------

    def _aggregate_categorical(
        self, df: pd.DataFrame, features: pd.DataFrame
    ) -> pd.DataFrame:
        """聚合地理、监测对象等分类特征的众数"""
        cat_cols = {
            "src_country": "country",
            "src_province": "province",
            "src_city": "city",
            "src_isp": "isp",
            "src_as": "as_number",
            "src_mo_name": "src_mo_name",
            "src_mo_code": "src_mo_code",
            "dst_mo_name": "dst_mo_name",
            "dst_mo_code": "dst_mo_code",
        }

        for src_col, dst_col in cat_cols.items():
            if src_col not in df.columns:
                features[dst_col] = None
                continue
            mode_series = df.groupby("src_ip_addr")[src_col].agg(
                lambda x: x.mode().iloc[0] if not x.mode().empty else None
            )
            features[dst_col] = mode_series

        # TCP 标志众数
        if "tcp_flags" in df.columns:
            features["dominant_tcp_flag"] = df.groupby("src_ip_addr")["tcp_flags"].agg(
                lambda x: x.mode().iloc[0] if not x.mode().empty else 0
            )

        # 主导协议（用于攻击类型推断）
        if "protocol" in df.columns:
            features["dominant_protocol"] = df.groupby("src_ip_addr")["protocol"].agg(
                lambda x: x.mode().iloc[0] if not x.mode().empty else 0
            )

        # 主导目的端口
        if "dst_port" in df.columns:
            features["dominant_dst_port"] = df.groupby("src_ip_addr")["dst_port"].agg(
                lambda x: x.mode().iloc[0] if not x.mode().empty else 0
            )

        return features
