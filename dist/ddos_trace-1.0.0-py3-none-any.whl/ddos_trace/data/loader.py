"""ClickHouse 数据加载与过滤模块"""

import logging
from datetime import datetime
from typing import List, Optional

import pandas as pd

from ddos_trace.config.models import ClickHouseConfig

logger = logging.getLogger(__name__)

# ClickHouse 查询需要的字段列表
QUERY_COLUMNS = [
    "flow_ip_addr",
    "src_ip_addr",
    "dst_ip_addr",
    "octets",
    "packets",
    "src_port",
    "dst_port",
    "tcp_flags",
    "protocol",
    "input_if_index",
    "output_if_index",
    "first_time",
    "last_time",
    "parser_rcv_time",
    "src_mo_name",
    "src_mo_code",
    "dst_mo_name",
    "dst_mo_code",
    "src_country",
    "src_province",
    "src_city",
    "src_isp",
    "src_as",
    "dst_country",
    "dst_province",
    "dst_city",
    "dst_isp",
]


class ClickHouseLoader:
    """从 ClickHouse 加载 NetFlow 数据"""

    def __init__(self, config: ClickHouseConfig):
        self.config = config
        self._client = None

    def _get_client(self):
        """懒加载 ClickHouse 客户端"""
        if self._client is None:
            try:
                from clickhouse_driver import Client

                self._client = Client(**self.config.connection_params)
                # 测试连接
                self._client.execute("SELECT 1")
                logger.info(
                    "[CLICKHOUSE] 连接成功 / host[%s] / port[%s] / database[%s]",
                    self.config.host,
                    self.config.port,
                    self.config.database,
                )
            except ImportError:
                raise ImportError(
                    "需要安装 clickhouse-driver: pip install clickhouse-driver"
                )
            except Exception as e:
                raise ConnectionError(
                    f"ClickHouse 连接失败: {e}"
                ) from e
        return self._client

    def load_data(
        self,
        target_ips: Optional[List[str]] = None,
        target_mo_codes: Optional[List[str]] = None,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
    ) -> pd.DataFrame:
        """
        从 ClickHouse 查询 NetFlow 数据

        Args:
            target_ips: 目的IP列表，为空则不过滤
            target_mo_codes: 目的监测对象编码列表，为空则不过滤
            start_time: 开始时间
            end_time: 结束时间

        Returns:
            包含原始 NetFlow 数据的 DataFrame
        """
        query, params = self._build_query(target_ips, target_mo_codes, start_time, end_time)
        logger.info("[DATA_LOADER] 执行查询 / 预计返回字段[%d]", len(QUERY_COLUMNS))

        client = self._get_client()

        try:
            result = client.query_dataframe(query, params)
        except Exception as e:
            logger.error("[DATA_LOADER] 查询失败 / 异常[%s]", e)
            raise

        if result.empty:
            logger.warning("[DATA_LOADER] 查询结果为空")
            return result

        logger.info(
            "[DATA_LOADER] 查询完成 / 记录数[%d] / 列数[%d]",
            len(result),
            len(result.columns),
        )
        return result

    def _build_query(
        self,
        target_ips: Optional[List[str]],
        target_mo_codes: Optional[List[str]],
        start_time: Optional[datetime],
        end_time: Optional[datetime],
    ) -> tuple:
        """构建 SQL 查询"""
        cols = ", ".join(QUERY_COLUMNS)
        table = f"{self.config.database}.{self.config.table_name}"

        conditions = []
        params = {}

        # 目的IP过滤（clickhouse-driver 要求 IN 参数用 tuple）
        if target_ips:
            conditions.append("dst_ip_addr IN %(target_ips)s")
            params["target_ips"] = tuple(target_ips)

        # 监测对象过滤
        if target_mo_codes:
            conditions.append("dst_mo_code IN %(target_mo_codes)s")
            params["target_mo_codes"] = tuple(target_mo_codes)

        # 时间范围过滤（使用 app_rcv_time 作为分区键优化查询）
        if start_time:
            conditions.append("app_rcv_time >= %(start_time)s")
            params["start_time"] = start_time
        if end_time:
            conditions.append("app_rcv_time <= %(end_time)s")
            params["end_time"] = end_time

        where_clause = ""
        if conditions:
            where_clause = "WHERE " + " AND ".join(conditions)

        query = f"SELECT {cols} FROM {table} {where_clause} ORDER BY parser_rcv_time"
        return query, params


class DataPreprocessor:
    """数据预处理 - 时间解析、类型转换、过滤"""

    def process(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        对原始数据进行预处理

        Args:
            df: 原始 ClickHouse 查询结果

        Returns:
            预处理后的 DataFrame
        """
        if df.empty:
            return df

        df = df.copy()

        # 时间字段转换：parser_rcv_time（毫秒）→ datetime
        if "parser_rcv_time" in df.columns:
            df["flow_time"] = pd.to_datetime(df["parser_rcv_time"], unit="ms")

        # first_time / last_time 也转换为 datetime
        if "first_time" in df.columns:
            df["first_time_dt"] = pd.to_datetime(df["first_time"], unit="ms", errors="coerce")
        if "last_time" in df.columns:
            df["last_time_dt"] = pd.to_datetime(df["last_time"], unit="ms", errors="coerce")

        # 确保数值类型正确
        numeric_cols = ["octets", "packets", "src_port", "dst_port",
                        "tcp_flags", "protocol", "input_if_index", "output_if_index"]
        for col in numeric_cols:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce")

        logger.info(
            "[PREPROCESSOR] 预处理完成 / 记录数[%d] / 时间范围[%s ~ %s]",
            len(df),
            df["flow_time"].min() if "flow_time" in df.columns else "N/A",
            df["flow_time"].max() if "flow_time" in df.columns else "N/A",
        )
        return df
