"""告警数据加载器 - 从 detect_attack_dist 读取告警记录"""

import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional

import pandas as pd

from ddos_trace.config.models import ClickHouseConfig

logger = logging.getLogger(__name__)


@dataclass
class AttackContext:
    """
    攻击上下文 — 由告警记录自动填充

    封装了从告警表获取的所有关键信息，
    替代原来需要用户手动传入的 target_ips / 时间范围 / 阈值。
    """

    # 来源标识
    attack_id: Optional[str] = None
    alert_ids: List[int] = field(default_factory=list)

    # 攻击目标
    attack_target: str = ""
    attack_target_type: str = ""  # ipv4 / mo / customer ...
    target_ips: List[str] = field(default_factory=list)
    target_mo_codes: List[str] = field(default_factory=list)

    # 时间窗口
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None

    # 阈值（从告警记录获取）
    threshold_pps: Optional[float] = None
    threshold_bps: Optional[float] = None
    threshold_raw: Optional[int] = None
    threshold_unit: Optional[str] = None

    # 攻击类型信息
    attack_types: List[str] = field(default_factory=list)
    attack_maintype: Optional[str] = None
    direction: str = "in"
    level: str = ""

    # 告警中的峰值（用于参考）
    max_pps: Optional[float] = None
    max_bps: Optional[float] = None
    mean_pps: Optional[float] = None
    mean_bps: Optional[float] = None

    def get_pps_threshold(self, fallback: float = 500_000) -> float:
        """获取 PPS 阈值，若无则使用兜底值"""
        return self.threshold_pps if self.threshold_pps is not None else fallback

    def get_bps_threshold(self, fallback: float = 20_000_000) -> float:
        """获取 BPS 阈值，若无则使用兜底值"""
        return self.threshold_bps if self.threshold_bps is not None else fallback


class AlertLoader:
    """从 detect_attack_dist 加载告警记录"""

    ALERT_COLUMNS = [
        "id", "attack_id", "attack_target", "attack_target_type",
        "level", "status", "attack_types", "attack_maintype",
        "threshold_unit", "threshold", "direction",
        "start_time", "end_time",
        "max_pps", "max_bps", "mean_packet_ps", "mean_bytes_ps",
        "duration", "daytime",
        "custcode", "isp_code",
    ]

    def __init__(self, config: ClickHouseConfig):
        self.config = config
        self._client = None

    def _get_client(self):
        if self._client is None:
            from clickhouse_driver import Client

            self._client = Client(**self.config.connection_params)
        return self._client

    def load_by_attack_id(self, attack_id: str) -> Optional[AttackContext]:
        """
        通过 attack_id 加载告警记录，构建攻击上下文

        一个 attack_id 可能对应多条告警记录（多条聚合），
        将它们合并为一个 AttackContext。
        """
        table = f"{self.config.database}.{self.config.alert_table_name}"
        cols = ", ".join(self.ALERT_COLUMNS)
        query = f"SELECT {cols} FROM {table} WHERE attack_id = %(attack_id)s"
        params = {"attack_id": attack_id}

        logger.info("[ALERT_LOADER] 查询告警 / attack_id[%s]", attack_id)
        client = self._get_client()

        try:
            df = client.query_dataframe(query, params)
        except Exception as e:
            logger.error("[ALERT_LOADER] 查询失败 / %s", e)
            raise

        if df.empty:
            logger.warning("[ALERT_LOADER] 未找到告警记录 / attack_id[%s]", attack_id)
            return None

        return self._build_context(df)

    def load_by_target(
        self,
        attack_target: str,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
    ) -> Optional[AttackContext]:
        """
        通过攻击目标 + 时间范围加载告警记录
        """
        table = f"{self.config.database}.{self.config.alert_table_name}"
        cols = ", ".join(self.ALERT_COLUMNS)

        conditions = ["attack_target = %(attack_target)s"]
        params = {"attack_target": attack_target}

        if start_time:
            conditions.append("start_time >= %(start_time)s")
            params["start_time"] = start_time
        if end_time:
            conditions.append("end_time <= %(end_time)s")
            params["end_time"] = end_time

        where = " AND ".join(conditions)
        query = f"SELECT {cols} FROM {table} WHERE {where} ORDER BY start_time DESC LIMIT 10"

        logger.info(
            "[ALERT_LOADER] 查询告警 / target[%s] / time[%s ~ %s]",
            attack_target, start_time, end_time,
        )
        client = self._get_client()

        try:
            df = client.query_dataframe(query, params)
        except Exception as e:
            logger.error("[ALERT_LOADER] 查询失败 / %s", e)
            raise

        if df.empty:
            logger.warning("[ALERT_LOADER] 未找到告警记录 / target[%s]", attack_target)
            return None

        return self._build_context(df)

    def _build_context(self, df: pd.DataFrame) -> AttackContext:
        """将告警 DataFrame 合并为单个 AttackContext"""
        # 取第一条作为主要信息来源
        first = df.iloc[0]

        # 合并所有 target_ips：如果 attack_target_type 是 ipv4，则直接用 attack_target
        target_type = _val(first, "attack_target_type", "")
        main_target = _val(first, "attack_target", "")

        target_ips = []
        target_mo_codes = []

        if target_type == "ipv4":
            # 可能有多条记录对应不同的目标IP
            target_ips = df["attack_target"].dropna().unique().tolist()
        elif target_type == "mo":
            target_mo_codes = df["attack_target"].dropna().unique().tolist()
        else:
            # 尝试同时使用
            target_ips = [main_target] if main_target else []

        # 时间窗口：取所有记录的最早 start_time 和最晚 end_time
        start_times = pd.to_datetime(df["start_time"], errors="coerce")
        end_times = pd.to_datetime(df["end_time"], errors="coerce")
        ctx_start = start_times.min()
        ctx_end = end_times.max()

        # 如果没有有效的 end_time，用 start_time + duration
        if pd.isna(ctx_end) and "duration" in df.columns:
            max_dur_ms = df["duration"].max()
            if pd.notna(max_dur_ms):
                ctx_end = ctx_start + pd.Timedelta(milliseconds=max_dur_ms)

        # 阈值：取最大的 threshold 作为检测阈值
        threshold_raw = None
        if "threshold" in df.columns:
            valid_thresholds = df["threshold"].dropna()
            if not valid_thresholds.empty:
                threshold_raw = float(valid_thresholds.max())
        threshold_unit = _val(first, "threshold_unit", "")

        threshold_pps = None
        threshold_bps = None
        if threshold_raw is not None and threshold_unit:
            unit_lower = threshold_unit.lower()
            if "pps" in unit_lower or "packet" in unit_lower:
                # pps / kpps / mpps 单位转换
                if "mpps" in unit_lower or "mpps" in unit_lower:
                    threshold_pps = float(threshold_raw) * 1_000_000
                elif "kpps" in unit_lower:
                    threshold_pps = float(threshold_raw) * 1_000
                else:
                    threshold_pps = float(threshold_raw)
            elif "bps" in unit_lower or "byte" in unit_lower or "mb" in unit_lower:
                # bps / Kbps / Mbps / Gbps 单位转换
                if "gbps" in unit_lower or "g" in unit_lower:
                    threshold_bps = float(threshold_raw) * 1_000_000_000
                elif "mbps" in unit_lower or "mb" in unit_lower or "m" in unit_lower:
                    threshold_bps = float(threshold_raw) * 1_000_000
                elif "kbps" in unit_lower or "kb" in unit_lower or "k" in unit_lower:
                    threshold_bps = float(threshold_raw) * 1_000
                else:
                    threshold_bps = float(threshold_raw)

        # 同时用 max_pps / max_bps 作为参考来反推阈值
        if threshold_pps is None and "max_pps" in df.columns:
            max_pps_val = df["max_pps"].max()
            if pd.notna(max_pps_val) and max_pps_val > 0:
                # 告警峰值说明至少超过了这个值，可以用来估算
                threshold_pps = max_pps_val * 0.5  # 取峰值的50%作为保守阈值
        if threshold_bps is None and "max_bps" in df.columns:
            max_bps_val = df["max_bps"].max()
            if pd.notna(max_bps_val) and max_bps_val > 0:
                threshold_bps = max_bps_val * 0.5

        # 合并攻击类型
        all_types = set()
        for types_str in df["attack_types"].dropna().unique():
            for t in str(types_str).split(","):
                t = t.strip()
                if t:
                    all_types.add(t)

        ctx = AttackContext(
            attack_id=_val(first, "attack_id"),
            alert_ids=df["id"].dropna().astype(int).tolist(),
            attack_target=main_target,
            attack_target_type=target_type,
            target_ips=target_ips,
            target_mo_codes=target_mo_codes,
            start_time=ctx_start.to_pydatetime() if pd.notna(ctx_start) else None,
            end_time=ctx_end.to_pydatetime() if pd.notna(ctx_end) else None,
            threshold_pps=threshold_pps,
            threshold_bps=threshold_bps,
            threshold_raw=int(threshold_raw) if threshold_raw is not None else None,            threshold_unit=threshold_unit,
            attack_types=sorted(all_types),
            attack_maintype=_val(first, "attack_maintype"),
            direction=_val(first, "direction", "in"),
            level=_val(first, "level", ""),
            max_pps=_float(df["max_pps"].max()) if "max_pps" in df.columns else None,
            max_bps=_float(df["max_bps"].max()) if "max_bps" in df.columns else None,
            mean_pps=_float(df["mean_packet_ps"].mean()) if "mean_packet_ps" in df.columns else None,
            mean_bps=_float(df["mean_bytes_ps"].mean()) if "mean_bytes_ps" in df.columns else None,
        )

        logger.info(
            "[ALERT_LOADER] 告警上下文构建完成 / target[%s] / type[%s] / "
            "time[%s ~ %s] / threshold_pps[%s] / threshold_bps[%s] / "
            "attack_types%s / alerts[%d]",
            ctx.attack_target,
            ctx.attack_target_type,
            ctx.start_time,
            ctx.end_time,
            ctx.threshold_pps,
            ctx.threshold_bps,
            ctx.attack_types,
            len(ctx.alert_ids),
        )
        return ctx


def _val(row_or_series, key: str, default: str = None):
    """安全取值"""
    if isinstance(row_or_series, pd.Series):
        v = row_or_series.get(key)
    else:
        v = row_or_series.get(key, default) if hasattr(row_or_series, "get") else default
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return default
    return str(v)


def _float(v) -> Optional[float]:
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return None
    return float(v)
