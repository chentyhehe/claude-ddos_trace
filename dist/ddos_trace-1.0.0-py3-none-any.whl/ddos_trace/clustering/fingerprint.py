"""攻击指纹聚类模块 - 三级算法降级策略"""

import logging
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from ddos_trace.config.models import TracebackConfig

logger = logging.getLogger(__name__)


class AttackFingerprintClusterer:
    """攻击源指纹聚类 - 识别僵尸网络团伙"""

    def __init__(self, config: TracebackConfig):
        self.config = config

    def cluster(
        self, features: pd.DataFrame
    ) -> Optional[pd.DataFrame]:
        """
        对异常源进行聚类分析

        Args:
            features: 仅包含 anomaly_sources（confirmed + suspicious）的特征

        Returns:
            聚类报告 DataFrame，每行一个集群；如果样本不足返回 None
        """
        if len(features) < self.config.min_cluster_size:
            logger.info(
                "[CLUSTER] 异常源数[%d] < 最小聚类数[%d]，跳过聚类",
                len(features),
                self.config.min_cluster_size,
            )
            return None

        logger.info("[CLUSTER] 开始聚类 / 异常源数[%d]", len(features))

        # 提取 9 维特征
        feature_cols = self.config.cluster_features
        available_cols = [c for c in feature_cols if c in features.columns]
        if len(available_cols) < 3:
            logger.warning("[CLUSTER] 可用特征不足，跳过聚类")
            return None

        X = features[available_cols].fillna(0).values

        # 标准化
        from sklearn.preprocessing import RobustScaler

        scaler = RobustScaler()
        X_scaled = scaler.fit_transform(X)

        # 大数据保护
        sampled = len(X_scaled) > self.config.max_samples_for_clustering
        if sampled:
            logger.info(
                "[CLUSTER] 样本数[%d] > 阈值[%d]，启用采样训练",
                len(X_scaled),
                self.config.max_samples_for_clustering,
            )
            rng = np.random.default_rng(42)
            sample_idx = rng.choice(
                len(X_scaled), self.config.max_samples_for_clustering, replace=False
            )
            X_train = X_scaled[sample_idx]
        else:
            X_train = X_scaled

        # 三级算法降级
        labels = self._fit_cluster(X_train, X_scaled, sampled, sample_idx if sampled else None)

        if labels is None:
            logger.warning("[CLUSTER] 所有聚类算法均失败")
            return None

        # 将标签附加到 features
        features = features.copy()
        features["cluster_id"] = labels

        # 生成聚类报告
        report = self._build_report(features, available_cols)
        logger.info(
            "[CLUSTER] 聚类完成 / 集群数[%d]",
            report["cluster_id"].nunique(),
        )
        return report

    # ------------------------------------------------------------------
    # 三级算法降级
    # ------------------------------------------------------------------

    def _fit_cluster(
        self,
        X_train: np.ndarray,
        X_full: np.ndarray,
        sampled: bool,
        sample_idx: Optional[np.ndarray],
    ) -> Optional[np.ndarray]:
        """
        三级降级：HDBSCAN → DBSCAN → MiniBatchKMeans
        """
        # 尝试 HDBSCAN
        labels = self._try_hdbscan(X_train, X_full, sampled, sample_idx)
        if labels is not None:
            return labels

        # 尝试 DBSCAN
        labels = self._try_dbscan(X_train, X_full, sampled, sample_idx)
        if labels is not None:
            return labels

        # 兜底 MiniBatchKMeans
        return self._fallback_kmeans(X_train, X_full, sampled, sample_idx)

    def _try_hdbscan(
        self,
        X_train: np.ndarray,
        X_full: np.ndarray,
        sampled: bool,
        sample_idx: Optional[np.ndarray],
    ) -> Optional[np.ndarray]:
        """首选: HDBSCAN"""
        try:
            import hdbscan

            clusterer = hdbscan.HDBSCAN(
                min_cluster_size=self.config.min_cluster_size,
                metric="euclidean",
            )
            train_labels = clusterer.fit_predict(X_train)
            logger.info("[CLUSTER] HDBSCAN 成功 / 训练标签数[%d]", len(train_labels))
            return self._extend_labels(train_labels, X_full, sampled, sample_idx)
        except ImportError:
            logger.info("[CLUSTER] hdbscan 未安装，尝试 DBSCAN")
            return None
        except Exception as e:
            logger.warning("[CLUSTER] HDBSCAN 失败: %s", e)
            return None

    def _try_dbscan(
        self,
        X_train: np.ndarray,
        X_full: np.ndarray,
        sampled: bool,
        sample_idx: Optional[np.ndarray],
    ) -> Optional[np.ndarray]:
        """次选: DBSCAN (ball_tree)"""
        try:
            from sklearn.cluster import DBSCAN

            clusterer = DBSCAN(
                eps=0.5,
                min_samples=self.config.min_cluster_size,
                algorithm="ball_tree",
            )
            train_labels = clusterer.fit_predict(X_train)
            logger.info("[CLUSTER] DBSCAN 成功 / 训练标签数[%d]", len(train_labels))
            return self._extend_labels(train_labels, X_full, sampled, sample_idx)
        except Exception as e:
            logger.warning("[CLUSTER] DBSCAN 失败: %s", e)
            return None

    def _fallback_kmeans(
        self,
        X_train: np.ndarray,
        X_full: np.ndarray,
        sampled: bool,
        sample_idx: Optional[np.ndarray],
    ) -> Optional[np.ndarray]:
        """兜底: MiniBatchKMeans"""
        try:
            from sklearn.cluster import MiniBatchKMeans

            n_clusters = max(2, min(10, len(X_train) // self.config.min_cluster_size))
            clusterer = MiniBatchKMeans(
                n_clusters=n_clusters,
                random_state=42,
                batch_size=min(1000, len(X_train)),
            )
            train_labels = clusterer.fit_predict(X_train)
            logger.info("[CLUSTER] MiniBatchKMeans 成功 / K[%d]", n_clusters)
            return self._extend_labels(train_labels, X_full, sampled, sample_idx)
        except Exception as e:
            logger.error("[CLUSTER] MiniBatchKMeans 也失败: %s", e)
            return None

    def _extend_labels(
        self,
        train_labels: np.ndarray,
        X_full: np.ndarray,
        sampled: bool,
        sample_idx: Optional[np.ndarray],
    ) -> np.ndarray:
        """
        如果使用了采样，通过 1-NN 将标签回传到全量样本
        """
        if not sampled:
            return train_labels

        from sklearn.neighbors import KNeighborsClassifier

        # 过滤噪声点（标签 -1）
        valid = train_labels >= 0
        if valid.sum() < 2:
            return train_labels

        knn = KNeighborsClassifier(n_neighbors=1)
        knn.fit(
            X_full[sample_idx][valid],
            train_labels[valid],
        )
        full_labels = knn.predict(X_full)
        return full_labels

    # ------------------------------------------------------------------
    # 聚类报告
    # ------------------------------------------------------------------

    def _build_report(
        self, features: pd.DataFrame, feature_cols: List[str]
    ) -> pd.DataFrame:
        """生成每个集群的汇总报告"""
        rows = []
        for cluster_id, group in features.groupby("cluster_id"):
            if cluster_id == -1:
                # 噪声点
                continue

            row = {
                "cluster_id": cluster_id,
                "member_count": len(group),
                "member_ips": ",".join(group.index.astype(str)),
            }
            # 平均指纹特征
            for col in feature_cols:
                if col in group.columns:
                    row[f"avg_{col}"] = group[col].mean()

            # 攻击类型推断
            row["attack_type"] = self._infer_attack_type(group)

            rows.append(row)

        return pd.DataFrame(rows)

    def _infer_attack_type(self, group: pd.DataFrame) -> str:
        """推断集群的攻击类型"""
        avg_bpp = group.get("bytes_per_packet", pd.Series([0])).mean()

        # 使用主导协议（众数），而非 protocol_count
        proto = 0
        if "dominant_protocol" in group.columns:
            mode_vals = group["dominant_protocol"].dropna().mode()
            if not mode_vals.empty:
                proto = int(mode_vals.iloc[0])

        # 协议常量: 1=ICMP, 6=TCP, 17=UDP
        if avg_bpp < 100 and proto == 6:
            return "SYN Flood"
        if avg_bpp < 100:
            return "小包洪泛"
        if avg_bpp > 1400:
            return "大包洪泛"
        if proto == 17:
            return "UDP Flood"
        if proto == 1:
            return "ICMP Flood"
        if proto == 6:
            return "TCP Flood"
        return "混合型攻击"
