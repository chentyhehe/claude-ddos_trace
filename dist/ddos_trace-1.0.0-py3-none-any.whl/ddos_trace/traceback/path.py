"""攻击路径重构模块 - 入口路由器分析、地理溯源、监测对象关联"""

import logging
from typing import Dict

import pandas as pd

logger = logging.getLogger(__name__)


class AttackPathReconstructor:
    """攻击路径重构"""

    def __init__(self, top_k: int = 5):
        self.top_k = top_k

    def reconstruct(
        self, raw_df: pd.DataFrame, features: pd.DataFrame
    ) -> Dict:
        """
        执行完整的路径重构分析

        Args:
            raw_df: 原始 NetFlow 数据
            features: 带有 traffic_class 的特征 DataFrame

        Returns:
            路径分析结果字典
        """
        # 只分析异常源（confirmed + suspicious）
        anomaly_ips = features.index[
            features["traffic_class"].isin(["confirmed", "suspicious"])
        ]
        anomaly_raw = raw_df[raw_df["src_ip_addr"].isin(anomaly_ips)]

        if anomaly_raw.empty:
            logger.warning("[PATH] 无异常源数据，跳过路径重构")
            return {
                "entry_routers": pd.DataFrame(),
                "geo_distribution": pd.DataFrame(),
                "mo_distribution": pd.DataFrame(),
                "time_distribution": pd.DataFrame(),
            }

        result = {}
        result["entry_routers"] = self._analyze_entry_routers(anomaly_raw)
        result["geo_distribution"] = self._analyze_geo(anomaly_raw)
        result["mo_distribution"] = self._analyze_mo(anomaly_raw, features)
        result["time_distribution"] = self._analyze_time(anomaly_raw)

        logger.info(
            "[PATH] 路径重构完成 / 入口节点[%d] / 地理来源[%d]",
            len(result["entry_routers"]),
            len(result["geo_distribution"]),
        )
        return result

    def _analyze_entry_routers(self, df: pd.DataFrame) -> pd.DataFrame:
        """入口路由器分析：按 flow_ip_addr + input_if_index 聚合"""
        group_cols = ["flow_ip_addr", "input_if_index"]
        available = [c for c in group_cols if c in df.columns]
        if not available:
            return pd.DataFrame()

        result = (
            df.groupby(available)
            .agg(
                flow_count=("src_ip_addr", "count"),
                unique_source_ips=("src_ip_addr", "nunique"),
                total_packets=("packets", "sum"),
                total_bytes=("octets", "sum"),
            )
            .reset_index()
            .sort_values("flow_count", ascending=False)
            .head(self.top_k)
        )
        return result

    def _analyze_geo(self, df: pd.DataFrame) -> pd.DataFrame:
        """地理来源分析：按 src_country/province/city/isp 聚合"""
        group_cols = ["src_country", "src_province", "src_city", "src_isp"]
        available = [c for c in group_cols if c in df.columns]
        if not available:
            return pd.DataFrame()

        result = (
            df.groupby(available)
            .agg(
                unique_source_ips=("src_ip_addr", "nunique"),
                total_packets=("packets", "sum"),
                total_bytes=("octets", "sum"),
            )
            .reset_index()
            .sort_values("total_packets", ascending=False)
            .head(10)
        )
        return result

    def _analyze_mo(
        self, df: pd.DataFrame, features: pd.DataFrame
    ) -> pd.DataFrame:
        """监测对象关联分析"""
        group_cols = ["src_mo_code", "src_mo_name"]
        available = [c for c in group_cols if c in df.columns]
        if not available:
            return pd.DataFrame()

        result = (
            df.groupby(available)
            .agg(
                attacking_source_ips=("src_ip_addr", "nunique"),
                total_packets=("packets", "sum"),
                total_bytes=("octets", "sum"),
            )
            .reset_index()
            .sort_values("total_packets", ascending=False)
            .head(10)
        )
        return result

    def _analyze_time(self, df: pd.DataFrame) -> pd.DataFrame:
        """时间分布分析"""
        if "flow_time" not in df.columns:
            return pd.DataFrame()

        time_df = df.copy()
        time_df["hour"] = time_df["flow_time"].dt.floor("h")

        result = (
            time_df.groupby("hour")
            .agg(
                flow_count=("src_ip_addr", "count"),
                unique_source_ips=("src_ip_addr", "nunique"),
                total_packets=("packets", "sum"),
            )
            .reset_index()
            .sort_values("hour")
        )
        return result
