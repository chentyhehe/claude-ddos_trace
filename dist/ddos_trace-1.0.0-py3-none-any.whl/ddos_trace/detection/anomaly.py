"""基线建模与异常源检测模块"""

import logging
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd

from ddos_trace.config.models import ThresholdConfig, TracebackConfig

logger = logging.getLogger(__name__)

# 用于基线计算的 6 个核心指标
BASELINE_METRICS = [
    "packets_per_sec",
    "bytes_per_sec",
    "bytes_per_packet",
    "burst_ratio",
    "flow_interval_mean",
    "flow_interval_cv",
]

# 基线统计量
BASELINE_STAT_NAMES = ["mean", "median", "std", "p75", "p90", "p95", "p99", "max", "min"]


class TrafficBaseline:
    """流量基线建模"""

    def __init__(self, threshold_config: ThresholdConfig, traceback_config: TracebackConfig):
        self.threshold_config = threshold_config
        self.traceback_config = traceback_config

    def compute(self, features: pd.DataFrame) -> Tuple[pd.DataFrame, Dict]:
        """
        计算流量基线

        Args:
            features: 特征 DataFrame（以 src_ip_addr 为索引）

        Returns:
            (effective_thresholds, baseline_stats)
            - effective_thresholds: 每个指标的有效阈值
            - baseline_stats: 基线统计量字典
        """
        logger.info("[BASELINE] 开始基线计算 / 源IP数[%d]", len(features))

        # 步骤1: 初步筛选正常 IP
        normal_mask = (
            (features["packets_per_sec"] < self.threshold_config.pps_threshold)
            & (features["bytes_per_sec"] < self.threshold_config.bps_threshold)
        )
        normal_df = features.loc[normal_mask]

        # 若正常样本 < 10，退化使用全量
        if len(normal_df) < 10:
            logger.warning(
                "[BASELINE] 正常IP不足10个(实际%d)，退化使用全量数据",
                len(normal_df),
            )
            normal_df = features

        # 步骤2: 计算 6 个核心指标的统计量
        baseline_stats = {}
        for metric in BASELINE_METRICS:
            if metric not in features.columns:
                continue
            series = normal_df[metric].dropna()
            if series.empty:
                continue
            baseline_stats[metric] = {
                "mean": float(series.mean()),
                "median": float(series.median()),
                "std": float(series.std()) if len(series) > 1 else 0.0,
                "p75": float(series.quantile(0.75)),
                "p90": float(series.quantile(0.90)),
                "p95": float(series.quantile(0.95)),
                "p99": float(series.quantile(0.99)),
                "max": float(series.max()),
                "min": float(series.min()),
            }

        # 步骤3: 计算有效阈值
        effective_thresholds = self._compute_effective_thresholds(baseline_stats)
        logger.info(
            "[BASELINE] 基线计算完成 / 指标数[%d] / 动态阈值[%s]",
            len(baseline_stats),
            self.traceback_config.use_dynamic_baseline,
        )
        return effective_thresholds, baseline_stats

    def _compute_effective_thresholds(self, baseline_stats: Dict) -> Dict[str, float]:
        """
        计算有效阈值：max(配置阈值, P95)
        """
        effective = {}

        if self.traceback_config.use_dynamic_baseline:
            # PPS
            pps_p95 = baseline_stats.get("packets_per_sec", {}).get("p95", 0)
            effective["packets_per_sec"] = max(
                self.threshold_config.pps_threshold, pps_p95
            )
            # BPS
            bps_p95 = baseline_stats.get("bytes_per_sec", {}).get("p95", 0)
            effective["bytes_per_sec"] = max(
                self.threshold_config.bps_threshold, bps_p95
            )
        else:
            effective["packets_per_sec"] = float(self.threshold_config.pps_threshold)
            effective["bytes_per_sec"] = float(self.threshold_config.bps_threshold)

        return effective


class AnomalyDetector:
    """异常源检测 - 多因子评分模型"""

    def __init__(
        self,
        threshold_config: ThresholdConfig,
        traceback_config: TracebackConfig,
    ):
        self.threshold_config = threshold_config
        self.traceback_config = traceback_config

    def detect(
        self,
        features: pd.DataFrame,
        baseline_stats: Dict,
        effective_thresholds: Dict,
    ) -> pd.DataFrame:
        """
        执行异常检测，返回带分类的 features

        Args:
            features: 特征 DataFrame
            baseline_stats: 基线统计量
            effective_thresholds: 有效阈值

        Returns:
            添加了 attack_confidence、traffic_class 等列的 DataFrame
        """
        if features.empty:
            return features

        features = features.copy()

        logger.info("[DETECTION] 开始异常检测 / 源IP数[%d]", len(features))

        # 因子1: PPS 超标程度 (30%)
        f1 = self._score_pps(features, baseline_stats, effective_thresholds)
        # 因子2: BPS 超标程度 (25%)
        f2 = self._score_bps(features, baseline_stats, effective_thresholds)
        # 因子3: 包大小异常 (15%)
        f3 = self._score_packet_size(features, baseline_stats)
        # 因子4: 突发模式 (15%)
        f4 = self._score_burst(features)
        # 因子5: 行为模式 (15%)
        f5 = self._score_behavior(features)

        # 加权总分
        features["attack_confidence"] = (
            f1 * 0.30 + f2 * 0.25 + f3 * 0.15 + f4 * 0.15 + f5 * 0.15
        ).clip(0, 100)

        # 分层分类
        features["traffic_class"] = pd.cut(
            features["attack_confidence"],
            bins=[-1, 40, 60, 80, 101],
            labels=["background", "borderline", "suspicious", "confirmed"],
        ).astype(str)

        # 生成置信度说明
        features["confidence_reasons"] = self._generate_reasons(
            features, f1, f2, f3, f4, f5
        )

        # 统计
        class_counts = features["traffic_class"].value_counts().to_dict()
        logger.info(
            "[DETECTION] 检测完成 / confirmed[%d] / suspicious[%d] / "
            "borderline[%d] / background[%d]",
            class_counts.get("confirmed", 0),
            class_counts.get("suspicious", 0),
            class_counts.get("borderline", 0),
            class_counts.get("background", 0),
        )
        return features

    # ------------------------------------------------------------------
    # 评分因子
    # ------------------------------------------------------------------

    def _score_pps(
        self, features: pd.DataFrame, baseline: Dict, thresholds: Dict
    ) -> pd.Series:
        """因子1: PPS 超标程度 (权重30%)"""
        pps = features["packets_per_sec"].fillna(0)
        bl = baseline.get("packets_per_sec", {})
        mean = bl.get("mean", 0)
        std = bl.get("std", 1) or 1

        # z-score 归一化到 0-100
        z = (pps - mean) / std
        z_score = np.clip(z * 10, 0, 100)

        # 硬阈值判断
        threshold = thresholds.get("packets_per_sec", self.threshold_config.pps_threshold)
        hard_score = np.where(pps >= threshold, np.clip((pps / threshold) * 50, 50, 100), 0)

        return pd.Series(np.maximum(z_score, hard_score), index=features.index)

    def _score_bps(
        self, features: pd.DataFrame, baseline: Dict, thresholds: Dict
    ) -> pd.Series:
        """因子2: BPS 超标程度 (权重25%)"""
        bps = features["bytes_per_sec"].fillna(0)
        bl = baseline.get("bytes_per_sec", {})
        mean = bl.get("mean", 0)
        std = bl.get("std", 1) or 1

        z = (bps - mean) / std
        z_score = np.clip(z * 10, 0, 100)

        threshold = thresholds.get("bytes_per_sec", self.threshold_config.bps_threshold)
        hard_score = np.where(bps >= threshold, np.clip((bps / threshold) * 50, 50, 100), 0)

        return pd.Series(np.maximum(z_score, hard_score), index=features.index)

    def _score_packet_size(
        self, features: pd.DataFrame, baseline: Dict
    ) -> pd.Series:
        """因子3: 包大小异常 - 双侧 z-score (权重15%)"""
        bpp = features["bytes_per_packet"].fillna(0)
        bl = baseline.get("bytes_per_packet", {})
        mean = bl.get("mean", 0)
        std = bl.get("std", 1) or 1

        # 双侧检测：绝对偏离
        z_abs = np.abs((bpp - mean) / std)
        score = np.clip(z_abs * 15, 0, 100)

        return pd.Series(score, index=features.index)

    def _score_burst(self, features: pd.DataFrame) -> pd.Series:
        """因子4: 突发模式 (权重15%)"""
        burst_ratio = features.get("burst_ratio", pd.Series(0, index=features.index)).fillna(0)
        burst_count = features.get("burst_count", pd.Series(0, index=features.index)).fillna(0)
        max_burst = features.get("max_burst_size", pd.Series(0, index=features.index)).fillna(0)

        # 归一化各维度
        ratio_score = np.clip(burst_ratio / 5.0 * 100, 0, 100)
        count_score = np.clip(burst_count / 100.0 * 100, 0, 100)
        size_score = np.clip(max_burst / 20.0 * 100, 0, 100)

        # 加权平均
        return pd.Series(
            ratio_score * 0.4 + count_score * 0.3 + size_score * 0.3,
            index=features.index,
        )

    def _score_behavior(self, features: pd.DataFrame) -> pd.Series:
        """因子5: 行为模式 - 单端口/单协议/规律性 (权重15%)"""
        single_port = (features.get("dst_port_count", 1) == 1).astype(float)
        single_proto = (features.get("protocol_count", 1) == 1).astype(float)
        flow_count = features.get("flow_count", pd.Series(1, index=features.index)).fillna(0)
        cv = features.get("flow_interval_cv", pd.Series(1, index=features.index)).fillna(1.0)
        regular = ((cv < 0.5) & (flow_count >= 5)).astype(float)

        # 满足条件越多分数越高
        score = (single_port + single_proto + regular) / 3.0 * 100
        return pd.Series(score, index=features.index)

    # ------------------------------------------------------------------
    # 置信度说明
    # ------------------------------------------------------------------

    def _generate_reasons(
        self,
        features: pd.DataFrame,
        f1: pd.Series,
        f2: pd.Series,
        f3: pd.Series,
        f4: pd.Series,
        f5: pd.Series,
    ) -> pd.Series:
        """为每个源 IP 生成置信度说明文本"""
        reasons_list = []
        for idx in features.index:
            reasons = []
            if f1.loc[idx] > 60:
                reasons.append(f"PPS超标(得分{f1.loc[idx]:.0f})")
            if f2.loc[idx] > 60:
                reasons.append(f"BPS超标(得分{f2.loc[idx]:.0f})")
            if f3.loc[idx] > 60:
                reasons.append(f"包大小异常(得分{f3.loc[idx]:.0f})")
            if f4.loc[idx] > 60:
                reasons.append(f"突发模式(得分{f4.loc[idx]:.0f})")
            if f5.loc[idx] > 60:
                reasons.append(f"行为模式异常(得分{f5.loc[idx]:.0f})")
            reasons_list.append("; ".join(reasons) if reasons else "未检出明显异常")
        return pd.Series(reasons_list, index=features.index)
