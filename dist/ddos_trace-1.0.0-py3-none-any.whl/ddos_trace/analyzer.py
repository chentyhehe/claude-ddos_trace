"""DDoS 攻击溯源分析器 - 主入口类"""

import logging
from datetime import datetime
from typing import Dict, List, Optional

import pandas as pd

from ddos_trace.config.models import (
    ClickHouseConfig,
    ThresholdConfig,
    TracebackConfig,
)
from ddos_trace.data.alert_loader import AlertLoader, AttackContext
from ddos_trace.data.loader import ClickHouseLoader, DataPreprocessor
from ddos_trace.features.extraction import FeatureExtractor
from ddos_trace.detection.anomaly import AnomalyDetector, TrafficBaseline
from ddos_trace.clustering.fingerprint import AttackFingerprintClusterer
from ddos_trace.traceback.path import AttackPathReconstructor
from ddos_trace.reports.generator import ReportGenerator

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)


class DDoSTracebackAnalyzer:
    """
    DDoS 攻击溯源分析器

    支持两种入口:
    1. 基于告警 ID: run_analysis_by_alert(attack_id)
       → 自动从告警表获取目标IP、阈值、时间窗口
    2. 手动传参: run_full_analysis(target_ips, target_mo_codes, start_time, end_time)
       → 使用配置文件中的默认阈值
    """

    def __init__(
        self,
        threshold_config: Optional[ThresholdConfig] = None,
        traceback_config: Optional[TracebackConfig] = None,
        clickhouse_config: Optional[ClickHouseConfig] = None,
        output_dir: str = ".",
    ):
        self.threshold_config = threshold_config or ThresholdConfig()
        self.traceback_config = traceback_config or TracebackConfig()
        self.clickhouse_config = clickhouse_config or ClickHouseConfig()
        self.output_dir = output_dir

        # 初始化各模块
        self._loader = ClickHouseLoader(self.clickhouse_config)
        self._preprocessor = DataPreprocessor()
        self._alert_loader = AlertLoader(self.clickhouse_config)
        self._extractor = FeatureExtractor()
        self._baseline = TrafficBaseline(self.threshold_config, self.traceback_config)
        self._detector = AnomalyDetector(self.threshold_config, self.traceback_config)
        self._clusterer = AttackFingerprintClusterer(self.traceback_config)
        self._reconstructor = AttackPathReconstructor()
        self._reporter = ReportGenerator(self.output_dir)

    # ------------------------------------------------------------------
    # 入口1: 基于告警 ID 分析（推荐）
    # ------------------------------------------------------------------

    def run_analysis_by_alert(self, attack_id: str) -> Dict:
        """
        通过告警 ID 执行溯源分析

        自动从告警表获取: target_ips、阈值、时间窗口、攻击类型

        Args:
            attack_id: 告警系统生成的攻击ID

        Returns:
            包含所有分析结果的字典（额外包含 attack_context）
        """
        logger.info("=" * 60)
        logger.info("DDoS 攻击溯源分析器 - 告警驱动模式")
        logger.info("attack_id: %s", attack_id)
        logger.info("=" * 60)

        # 1. 从告警表加载上下文
        ctx = self._alert_loader.load_by_attack_id(attack_id)
        if ctx is None:
            logger.error("未找到告警记录 / attack_id[%s]", attack_id)
            return {"error": f"未找到告警记录: attack_id={attack_id}"}

        logger.info(
            "[ALERT] 告警上下文 / target[%s] / type[%s] / "
            "threshold_pps[%s] / threshold_bps[%s] / "
            "attack_types%s / time[%s ~ %s]",
            ctx.attack_target, ctx.attack_target_type,
            ctx.threshold_pps, ctx.threshold_bps,
            ctx.attack_types, ctx.start_time, ctx.end_time,
        )

        # 2. 使用告警阈值覆盖配置阈值
        effective_threshold = ThresholdConfig(
            pps_threshold=int(ctx.get_pps_threshold(self.threshold_config.pps_threshold)),
            bps_threshold=int(ctx.get_bps_threshold(self.threshold_config.bps_threshold)),
        )
        # 临时替换 detector 和 baseline 的阈值
        baseline = TrafficBaseline(effective_threshold, self.traceback_config)
        detector = AnomalyDetector(effective_threshold, self.traceback_config)

        # 3. 加载 NetFlow 数据
        raw_df = self._load_data(
            target_ips=ctx.target_ips or None,
            target_mo_codes=ctx.target_mo_codes or None,
            start_time=ctx.start_time,
            end_time=ctx.end_time,
        )
        if raw_df.empty:
            return {"error": "查询结果为空", "attack_context": ctx}

        # 4. 特征工程
        features = self._extract_features(raw_df)

        # 5. 基线建模（使用告警阈值）
        eff_thresholds, baseline_stats = baseline.compute(features)

        # 6. 异常检测（使用告警阈值）
        features = detector.detect(features, baseline_stats, eff_thresholds)

        # 7. 指纹聚类
        anomaly_sources = features[features["traffic_class"].isin(["confirmed", "suspicious"])]
        cluster_report = self._cluster_fingerprints(anomaly_sources)

        # 8. 路径重构
        path_analysis = self._reconstruct_path(raw_df, features)

        # 9. 报告生成
        report = self._generate_reports(features, cluster_report, path_analysis, eff_thresholds)

        result = {
            "attack_context": ctx,
            "features": features,
            "traffic_classification": features[["traffic_class", "attack_confidence", "confidence_reasons"]],
            "anomaly_sources": anomaly_sources,
            "clusters": cluster_report,
            "path_analysis": path_analysis,
            "effective_thresholds": eff_thresholds,
            "baseline_stats": baseline_stats,
            "report": report,
        }

        logger.info("=" * 60)
        logger.info("DDoS 攻击溯源分析器 - 分析完成")
        logger.info("=" * 60)
        return result

    # ------------------------------------------------------------------
    # 入口2: 基于攻击目标 + 时间范围
    # ------------------------------------------------------------------

    def run_analysis_by_target(
        self,
        attack_target: str,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
    ) -> Dict:
        """
        通过攻击目标执行溯源分析

        自动从告警表获取: 阈值、攻击类型等

        Args:
            attack_target: 攻击目标（IP / 监测对象编码）
            start_time: 开始时间（可选，默认使用告警时间窗口）
            end_time: 结束时间（可选）

        Returns:
            包含所有分析结果的字典
        """
        logger.info("=" * 60)
        logger.info("DDoS 攻击溯源分析器 - 目标驱动模式")
        logger.info("attack_target: %s", attack_target)
        logger.info("=" * 60)

        ctx = self._alert_loader.load_by_target(attack_target, start_time, end_time)
        if ctx is None:
            logger.warning("未找到告警记录，使用配置文件默认阈值")
            ctx = AttackContext(
                attack_target=attack_target,
                target_ips=[attack_target],
                start_time=start_time,
                end_time=end_time,
            )

        # 使用告警时间窗口（若用户未指定）
        actual_start = start_time or ctx.start_time
        actual_end = end_time or ctx.end_time

        effective_threshold = ThresholdConfig(
            pps_threshold=int(ctx.get_pps_threshold(self.threshold_config.pps_threshold)),
            bps_threshold=int(ctx.get_bps_threshold(self.threshold_config.bps_threshold)),
        )

        raw_df = self._load_data(
            target_ips=ctx.target_ips or [attack_target],
            target_mo_codes=ctx.target_mo_codes or None,
            start_time=actual_start,
            end_time=actual_end,
        )
        if raw_df.empty:
            return {"error": "查询结果为空", "attack_context": ctx}

        features = self._extract_features(raw_df)
        baseline = TrafficBaseline(effective_threshold, self.traceback_config)
        detector = AnomalyDetector(effective_threshold, self.traceback_config)

        eff_thresholds, baseline_stats = baseline.compute(features)
        features = detector.detect(features, baseline_stats, eff_thresholds)

        anomaly_sources = features[features["traffic_class"].isin(["confirmed", "suspicious"])]
        cluster_report = self._cluster_fingerprints(anomaly_sources)
        path_analysis = self._reconstruct_path(raw_df, features)
        report = self._generate_reports(features, cluster_report, path_analysis, eff_thresholds)

        logger.info("=" * 60)
        logger.info("DDoS 攻击溯源分析器 - 分析完成")
        logger.info("=" * 60)

        return {
            "attack_context": ctx,
            "features": features,
            "traffic_classification": features[["traffic_class", "attack_confidence", "confidence_reasons"]],
            "anomaly_sources": anomaly_sources,
            "clusters": cluster_report,
            "path_analysis": path_analysis,
            "effective_thresholds": eff_thresholds,
            "baseline_stats": baseline_stats,
            "report": report,
        }

    # ------------------------------------------------------------------
    # 入口3: 手动传参（兼容旧接口）
    # ------------------------------------------------------------------

    def run_full_analysis(
        self,
        target_ips: Optional[List[str]] = None,
        target_mo_codes: Optional[List[str]] = None,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
    ) -> Dict:
        """
        手动传参执行溯源分析（使用配置文件中的默认阈值）

        Args:
            target_ips: 目的IP列表
            target_mo_codes: 目的监测对象编码列表
            start_time: 开始时间
            end_time: 结束时间

        Returns:
            包含所有分析结果的字典
        """
        logger.info("=" * 60)
        logger.info("DDoS 攻击溯源分析器 - 手动模式")
        logger.info("=" * 60)

        raw_df = self._load_data(target_ips, target_mo_codes, start_time, end_time)
        if raw_df.empty:
            return {"error": "查询结果为空"}

        features = self._extract_features(raw_df)
        effective_thresholds, baseline_stats = self._compute_baseline(features)
        features = self._detect_anomalies(features, baseline_stats, effective_thresholds)

        anomaly_sources = features[features["traffic_class"].isin(["confirmed", "suspicious"])]
        cluster_report = self._cluster_fingerprints(anomaly_sources)
        path_analysis = self._reconstruct_path(raw_df, features)
        report = self._generate_reports(features, cluster_report, path_analysis, effective_thresholds)

        return {
            "features": features,
            "traffic_classification": features[["traffic_class", "attack_confidence", "confidence_reasons"]],
            "anomaly_sources": anomaly_sources,
            "clusters": cluster_report,
            "path_analysis": path_analysis,
            "effective_thresholds": effective_thresholds,
            "baseline_stats": baseline_stats,
            "report": report,
        }

    # ------------------------------------------------------------------
    # 各阶段封装方法
    # ------------------------------------------------------------------

    def _load_data(
        self,
        target_ips: Optional[List[str]],
        target_mo_codes: Optional[List[str]],
        start_time: Optional[datetime],
        end_time: Optional[datetime],
    ) -> pd.DataFrame:
        """Phase 0: 数据加载与过滤"""
        logger.info("[Phase 0] 数据加载与过滤")
        raw_df = self._loader.load_data(target_ips, target_mo_codes, start_time, end_time)
        raw_df = self._preprocessor.process(raw_df)
        return raw_df

    def _extract_features(self, raw_df: pd.DataFrame) -> pd.DataFrame:
        """Phase 1: 特征提取"""
        logger.info("[Phase 1] 特征工程")
        return self._extractor.extract(raw_df)

    def _compute_baseline(self, features: pd.DataFrame):
        """Phase 1.5: 基线建模"""
        logger.info("[Phase 1.5] 流量基线建模")
        return self._baseline.compute(features)

    def _detect_anomalies(self, features, baseline_stats, effective_thresholds):
        """Phase 2: 异常检测"""
        logger.info("[Phase 2] 异常源检测")
        return self._detector.detect(features, baseline_stats, effective_thresholds)

    def _cluster_fingerprints(self, anomaly_sources: pd.DataFrame):
        """Phase 3: 指纹聚类"""
        logger.info("[Phase 3] 攻击指纹聚类")
        if len(anomaly_sources) < self.traceback_config.min_cluster_size:
            logger.info("异常源不足，跳过聚类")
            return None
        return self._clusterer.cluster(anomaly_sources)

    def _reconstruct_path(self, raw_df: pd.DataFrame, features: pd.DataFrame):
        """Phase 4: 路径重构"""
        logger.info("[Phase 4] 攻击路径重构")
        return self._reconstructor.reconstruct(raw_df, features)

    def _generate_reports(self, features, cluster_report, path_analysis, effective_thresholds):
        """Phase 5: 报告生成"""
        logger.info("[Phase 5] 报告生成与导出")
        report_text = self._reporter.generate_text_report(
            features, cluster_report, path_analysis, effective_thresholds
        )
        self._reporter.export_traffic_classification_csv(features)
        self._reporter.export_cluster_report_csv(cluster_report)
        self._reporter.plot_cluster_radar_chart(cluster_report)
        return report_text
