"""FastAPI 服务 - 对外暴露 DDoS 溯源分析 API"""

import logging
import os
import uuid
from datetime import datetime
from typing import List, Optional

import pandas as pd
from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, Field

from ddos_trace.analyzer import DDoSTracebackAnalyzer
from ddos_trace.config.models import load_config
from ddos_trace.data.alert_loader import AttackContext

logger = logging.getLogger(__name__)


# ------------------------------------------------------------------
# 请求模型
# ------------------------------------------------------------------

class AlertAnalysisRequest(BaseModel):
    """基于告警 ID 的分析请求（推荐）"""

    attack_id: str = Field(
        ..., description="告警系统生成的攻击ID",
        examples=["ATK-20260401-001"],
    )


class TargetAnalysisRequest(BaseModel):
    """基于攻击目标的分析请求"""

    attack_target: str = Field(
        ..., description="攻击目标（IP / 监测对象编码）",
        examples=["192.168.1.100"],
    )
    start_time: Optional[str] = Field(
        None, description="开始时间 (YYYY-MM-DD HH:MM:SS)，不传则使用告警时间窗口",
        examples=["2026-04-01 00:00:00"],
    )
    end_time: Optional[str] = Field(
        None, description="结束时间 (YYYY-MM-DD HH:MM:SS)，不传则使用告警时间窗口",
        examples=["2026-04-01 23:59:59"],
    )


class AnalysisRequest(BaseModel):
    """手动传参分析请求（兼容旧接口）"""

    target_ips: List[str] = Field(
        ..., description="目的IP列表",
        examples=[["192.168.1.100", "10.0.0.50"]],
    )
    target_mo_codes: List[str] = Field(
        ..., description="目的监测对象编码列表",
        examples=[["MO001", "MO002"]],
    )
    start_time: str = Field(
        ..., description="开始时间 (YYYY-MM-DD HH:MM:SS)",
        examples=["2026-04-01 00:00:00"],
    )
    end_time: str = Field(
        ..., description="结束时间 (YYYY-MM-DD HH:MM:SS)",
        examples=["2026-04-01 23:59:59"],
    )


# ------------------------------------------------------------------
# 响应模型
# ------------------------------------------------------------------

class AlertContextInfo(BaseModel):
    """告警上下文摘要信息"""

    attack_id: Optional[str] = None
    attack_target: str = ""
    attack_target_type: str = ""
    target_ips: List[str] = []
    target_mo_codes: List[str] = []
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    attack_types: List[str] = []
    attack_maintype: Optional[str] = None
    direction: str = "in"
    level: str = ""
    max_pps: Optional[float] = None
    max_bps: Optional[float] = None
    threshold_pps: Optional[float] = None
    threshold_bps: Optional[float] = None


class SourceSummary(BaseModel):
    """单个源 IP 的分类摘要"""

    src_ip: str
    attack_confidence: float
    traffic_class: str
    confidence_reasons: str
    packets_per_sec: float
    bytes_per_sec: float
    country: Optional[str] = None
    province: Optional[str] = None
    isp: Optional[str] = None


class ClusterSummary(BaseModel):
    """集群摘要"""

    cluster_id: int
    member_count: int
    member_ips: str
    attack_type: str


class GeoEntry(BaseModel):
    """地理分布条目"""

    src_country: Optional[str] = None
    src_province: Optional[str] = None
    src_city: Optional[str] = None
    src_isp: Optional[str] = None
    unique_source_ips: int
    total_packets: float
    total_bytes: float


class RouterEntry(BaseModel):
    """入口路由器条目"""

    flow_ip_addr: Optional[str] = None
    input_if_index: Optional[int] = None
    flow_count: int
    unique_source_ips: int
    total_packets: float
    total_bytes: float


class AnalysisResponse(BaseModel):
    """分析响应"""

    task_id: str
    status: str
    alert_context: Optional[AlertContextInfo] = None
    summary: dict
    anomaly_sources: List[SourceSummary]
    clusters: List[ClusterSummary] = []
    geo_distribution: List[GeoEntry] = []
    entry_routers: List[RouterEntry] = []
    report: str = ""


# ------------------------------------------------------------------
# FastAPI 应用
# ------------------------------------------------------------------

def create_app(config_path: Optional[str] = None) -> FastAPI:
    """创建 FastAPI 应用实例"""

    app = FastAPI(
        title="DDoS 攻击溯源分析器 API",
        version="2.0.0",
        description="基于 NetFlow 数据的 DDoS 攻击溯源分析服务",
    )

    # 加载配置并初始化分析器
    config = load_config(config_path)

    # 确保输出目录存在
    os.makedirs(config.output.dir, exist_ok=True)

    analyzer = DDoSTracebackAnalyzer(
        threshold_config=config.threshold,
        traceback_config=config.traceback,
        clickhouse_config=config.clickhouse,
        output_dir=config.output.dir,
    )

    @app.get("/health")
    async def health_check():
        """健康检查"""
        return {"status": "ok", "service": "ddos-trace"}

    # ------------------------------------------------------------------
    # POST /api/v1/analyze/alert  — 基于告警ID（推荐）
    # ------------------------------------------------------------------

    @app.post("/api/v1/analyze/alert", response_model=AnalysisResponse)
    async def analyze_by_alert(req: AlertAnalysisRequest):
        """
        基于告警 ID 执行溯源分析（推荐）

        自动从告警表获取目标IP、阈值、时间窗口、攻击类型等信息。
        """
        task_id = uuid.uuid4().hex[:12]
        logger.info(
            "[API] 收到告警分析请求 / task_id[%s] / attack_id[%s]",
            task_id, req.attack_id,
        )

        try:
            result = analyzer.run_analysis_by_alert(attack_id=req.attack_id)
        except Exception as e:
            logger.error("[API] 分析失败 / task_id[%s] / error[%s]", task_id, e)
            raise HTTPException(status_code=500, detail=f"分析失败: {e}")

        if "error" in result:
            raise HTTPException(status_code=404, detail=result["error"])

        return _build_response(task_id, result)

    # ------------------------------------------------------------------
    # POST /api/v1/analyze/target  — 基于攻击目标
    # ------------------------------------------------------------------

    @app.post("/api/v1/analyze/target", response_model=AnalysisResponse)
    async def analyze_by_target(req: TargetAnalysisRequest):
        """
        基于攻击目标执行溯源分析

        自动从告警表获取阈值和攻击类型；若未找到告警则使用配置文件默认阈值。
        """
        task_id = uuid.uuid4().hex[:12]
        logger.info(
            "[API] 收到目标分析请求 / task_id[%s] / target[%s] / time[%s ~ %s]",
            task_id, req.attack_target, req.start_time, req.end_time,
        )

        start = _parse_optional_time(req.start_time)
        end = _parse_optional_time(req.end_time)

        try:
            result = analyzer.run_analysis_by_target(
                attack_target=req.attack_target,
                start_time=start,
                end_time=end,
            )
        except Exception as e:
            logger.error("[API] 分析失败 / task_id[%s] / error[%s]", task_id, e)
            raise HTTPException(status_code=500, detail=f"分析失败: {e}")

        if "error" in result:
            raise HTTPException(status_code=404, detail=result["error"])

        return _build_response(task_id, result)

    # ------------------------------------------------------------------
    # POST /api/v1/analyze  — 手动传参（兼容旧接口）
    # ------------------------------------------------------------------

    @app.post("/api/v1/analyze", response_model=AnalysisResponse)
    async def analyze(req: AnalysisRequest):
        """
        手动传参执行溯源分析（使用配置文件中的默认阈值）

        传入目的IP、监测对象编码和时间范围，返回完整的分析结果。
        """
        task_id = uuid.uuid4().hex[:12]
        logger.info(
            "[API] 收到分析请求 / task_id[%s] / target_ips%s / target_mo%s / time[%s ~ %s]",
            task_id, req.target_ips, req.target_mo_codes, req.start_time, req.end_time,
        )

        try:
            start = datetime.strptime(req.start_time, "%Y-%m-%d %H:%M:%S")
            end = datetime.strptime(req.end_time, "%Y-%m-%d %H:%M:%S")
        except ValueError as e:
            raise HTTPException(status_code=400, detail=f"时间格式错误: {e}")

        try:
            result = analyzer.run_full_analysis(
                target_ips=req.target_ips,
                target_mo_codes=req.target_mo_codes,
                start_time=start,
                end_time=end,
            )
        except Exception as e:
            logger.error("[API] 分析失败 / task_id[%s] / error[%s]", task_id, e)
            raise HTTPException(status_code=500, detail=f"分析失败: {e}")

        if "error" in result:
            raise HTTPException(status_code=404, detail=result["error"])

        return _build_response(task_id, result)

    return app


# ------------------------------------------------------------------
# 响应构建
# ------------------------------------------------------------------

def _build_response(task_id: str, result: dict) -> AnalysisResponse:
    """从分析结果字典构建统一的 API 响应"""
    features = result["features"]

    # 分类统计
    class_counts = features["traffic_class"].value_counts().to_dict()
    summary = {
        "total_source_ips": len(features),
        "confirmed": class_counts.get("confirmed", 0),
        "suspicious": class_counts.get("suspicious", 0),
        "borderline": class_counts.get("borderline", 0),
        "background": class_counts.get("background", 0),
        "anomaly_total": class_counts.get("confirmed", 0) + class_counts.get("suspicious", 0),
    }

    # 异常源列表
    anomaly_df = result["anomaly_sources"]
    anomaly_list = []
    for ip, row in anomaly_df.iterrows():
        anomaly_list.append(SourceSummary(
            src_ip=str(ip),
            attack_confidence=round(float(row.get("attack_confidence", 0)), 2),
            traffic_class=str(row.get("traffic_class", "")),
            confidence_reasons=str(row.get("confidence_reasons", "")),
            packets_per_sec=round(float(row.get("packets_per_sec", 0)), 2),
            bytes_per_sec=round(float(row.get("bytes_per_sec", 0)), 2),
            country=_safe_str(row.get("country")),
            province=_safe_str(row.get("province")),
            isp=_safe_str(row.get("isp")),
        ))

    # 集群
    cluster_list = []
    cluster_report = result.get("clusters")
    if cluster_report is not None and not cluster_report.empty:
        for _, row in cluster_report.iterrows():
            cluster_list.append(ClusterSummary(
                cluster_id=int(row["cluster_id"]),
                member_count=int(row["member_count"]),
                member_ips=str(row.get("member_ips", "")),
                attack_type=str(row.get("attack_type", "未知")),
            ))

    # 地理分布
    geo_list = []
    geo_df = result.get("path_analysis", {}).get("geo_distribution", pd.DataFrame())
    if not geo_df.empty:
        for _, row in geo_df.iterrows():
            geo_list.append(GeoEntry(
                src_country=_safe_str(row.get("src_country")),
                src_province=_safe_str(row.get("src_province")),
                src_city=_safe_str(row.get("src_city")),
                src_isp=_safe_str(row.get("src_isp")),
                unique_source_ips=int(row.get("unique_source_ips", 0)),
                total_packets=float(row.get("total_packets", 0)),
                total_bytes=float(row.get("total_bytes", 0)),
            ))

    # 入口路由器
    router_list = []
    router_df = result.get("path_analysis", {}).get("entry_routers", pd.DataFrame())
    if not router_df.empty:
        for _, row in router_df.iterrows():
            router_list.append(RouterEntry(
                flow_ip_addr=_safe_str(row.get("flow_ip_addr")),
                input_if_index=_safe_int(row.get("input_if_index")),
                flow_count=int(row.get("flow_count", 0)),
                unique_source_ips=int(row.get("unique_source_ips", 0)),
                total_packets=float(row.get("total_packets", 0)),
                total_bytes=float(row.get("total_bytes", 0)),
            ))

    # 告警上下文
    alert_ctx = _build_alert_context(result.get("attack_context"))

    response = AnalysisResponse(
        task_id=task_id,
        status="completed",
        alert_context=alert_ctx,
        summary=summary,
        anomaly_sources=anomaly_list,
        clusters=cluster_list,
        geo_distribution=geo_list,
        entry_routers=router_list,
        report=result.get("report", ""),
    )

    logger.info(
        "[API] 分析完成 / task_id[%s] / confirmed[%d] / suspicious[%d]",
        task_id, summary["confirmed"], summary["suspicious"],
    )
    return response


def _build_alert_context(ctx: Optional[AttackContext]) -> Optional[AlertContextInfo]:
    """将 AttackContext 转换为 API 响应模型"""
    if ctx is None:
        return None
    return AlertContextInfo(
        attack_id=ctx.attack_id,
        attack_target=ctx.attack_target,
        attack_target_type=ctx.attack_target_type,
        target_ips=ctx.target_ips,
        target_mo_codes=ctx.target_mo_codes,
        start_time=ctx.start_time.isoformat() if ctx.start_time else None,
        end_time=ctx.end_time.isoformat() if ctx.end_time else None,
        attack_types=ctx.attack_types,
        attack_maintype=ctx.attack_maintype,
        direction=ctx.direction,
        level=ctx.level,
        max_pps=ctx.max_pps,
        max_bps=ctx.max_bps,
        threshold_pps=ctx.threshold_pps,
        threshold_bps=ctx.threshold_bps,
    )


def _parse_optional_time(time_str: Optional[str]) -> Optional[datetime]:
    """解析可选的时间字符串"""
    if time_str is None:
        return None
    try:
        return datetime.strptime(time_str, "%Y-%m-%d %H:%M:%S")
    except ValueError:
        return None


def _safe_str(val) -> Optional[str]:
    if val is None or (isinstance(val, float) and pd.isna(val)):
        return None
    return str(val)


def _safe_int(val) -> Optional[int]:
    if val is None or (isinstance(val, float) and pd.isna(val)):
        return None
    return int(val)
